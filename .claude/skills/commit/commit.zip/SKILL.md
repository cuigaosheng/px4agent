---
name: commit
version: "1.0.0"
description: 为当前改动创建一个规范的 git 提交。
disable-model-invocation: true
allowed-tools: [Bash, Read]
---
为当前改动创建一个规范的 git 提交。

## 步骤

1. 执行 `git status` 查看未跟踪和已修改的文件
2. 执行 `git diff` 查看具体改动内容
3. 执行 `git log --oneline -5` 参考历史提交风格

## 提交规范

- **提交信息用中文**
- 格式：`<类型>: <简短描述>`
- 类型：`新增` / `修复` / `重构` / `优化` / `测试` / `配置`
- 第一行不超过 50 字
- 如有必要，空一行后补充详细说明

## 注意事项
- 不提交 `CLAUDE.md`、`CLAUDE-*.md`、`HANDOFF.md`（已加入 .gitignore）
- 不提交 `.env`、密钥等敏感文件
- 优先 `git add` 指定文件，避免 `git add -A`

$ARGUMENTS
